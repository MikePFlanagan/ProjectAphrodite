/** @type {import('prettier').Config} */
export default { plugins: ['prettier-plugin-tailwindcss'], semi: true, singleQuote: true, printWidth: 100 };
